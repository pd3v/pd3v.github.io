A Max Externals collection wannabe (Mac/Intel Builds Only)

drunkad - Is a 'drunk'-like object with 2 more outputs: amount added to previous step value and step direction. 

drunkt - Is a 'drunk'-like object in which step max is redefined dynamically according to bang time intervals; has also 2 more outputs: amount added to previous step value and step direction.

mrkv - Markov chains object. Settable number of states. Settable probability transition matrix for a custom graph.
Randomly generated graphs. On bang outlets next state.
